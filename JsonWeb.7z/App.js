// import React from 'react';
// import { StyleSheet, Text, View } from 'react-native';

// export default function App() {
//   return (
//     <View style={styles.container}>
//       <Text>Open up App.js to start working on your app!</Text>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });
import React, { Component } from 'react';

import { AppRegistry, StyleSheet, FlatList, Text, View, Alert, ActivityIndicator, Platform} from 'react-native';

class App extends Component {
  
  constructor(props)
  {

    super(props);

    this.state = { 
    isLoading: true
  }
  }

  componentDidMount() {
    // http://10.0.0.5/reactnative/FruitsList.php
       return fetch('http://103.107.17.141:8080/RestWebService/services')
         .then((response) => response.json())
         .then((responseJson) => {


           this.setState({
             isLoading: false,
             dataSource: responseJson.projectList,
           }, function() {
             // In this block you can do something with new state.
           });

        
               // console.log(response);
         })
         .catch((error) => {
           console.error(error);
         });
     }

FlatListItemSeparator = () => {
    return (
      <View
        style={{
          
          width: "100%",
          backgroundColor: "#607D8B",
        }}
      />


    );
  }

  // GetFlatListItem (serviceName) {
   
  // Alert.alert(serviceName);

  // }


  render() {

    if (this.state.isLoading) {
      return (
        <View style={{flex: 1, paddingTop: 50}}>
          <ActivityIndicator />
        </View>
      );
    }

    return (

<View style={styles.MainContainer}>
       <FlatList
       
          data={ this.state.dataSource }
          
          // ItemSeparatorComponent = {this.FlatListItemSeparator}

          // renderItem={({item}) => <Text style={styles.FlatListItemStyle} 
          // onPress={this.GetFlatListItem.bind(this, item.serviceName,item.serviceId, item.srNo, item.serviceHead)} > 
          // <Text>srNo: {item.srNo} serviceName: {item.serviceName} serviceHead: {item.serviceHead} serviceId:{item.serviceId}</Text> </Text>}

          renderItem={({item}) => <Text>srNo: {item.srNo} ,serviceName: {item.serviceName} ,
          serviceHead: {item.serviceHead},serviceId:{item.serviceId} ,projectCity:{item.projectCity}</Text>}

          keyExtractor={(item, index) => index}
          
         />
    
    
</View>
            
    );
  }
}



export default App;

const styles = StyleSheet.create({

MainContainer :{

justifyContent: 'center',
flex:1,
margin: 10,
paddingTop: (Platform.OS === 'ios') ? 50 : 0,
fontSize: 5,

},

FlatListItemStyle: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },

});

AppRegistry.registerComponent('Project', () => Project);